library(testthat)
library(opendatauzb)

test_check("opendatauzb")
